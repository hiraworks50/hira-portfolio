# Hira — Social Media & Content Portfolio

Responsive one-page portfolio built with HTML, CSS, and JavaScript.

## Publish on GitHub Pages
1. Create a public repository on GitHub.
2. Upload `index.html`, `style.css`, `script.js`, and `README.md` to the repository root.
3. Open **Settings → Pages**.
4. Choose **Deploy from a branch**, branch `main`, folder `/(root)`, then save.
5. Wait for the published URL to appear in Settings → Pages.

## Before sharing with employers
- Confirm the Yoaglobal role, four-year duration, dates, and listed responsibilities are accurate.
- Replace LinkedIn and Instagram links with your real professional profiles.
- Add real Canva samples or project links. Concept examples are labelled as concepts.
- Contact email: `hiraworks50@gmail.com`.
